import streamlit as st

st.title("🚀 ISS Tracker - Test")
st.write("App is working!")

# Simple test without external APIs
st.write("This is a test to see if the app loads properly.")